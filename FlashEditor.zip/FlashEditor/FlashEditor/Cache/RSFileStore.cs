﻿using FlashEditor.utils;
using System.IO;

namespace FlashEditor.cache {
    public class RSFileStore {
        private JagStream dataChannel;
        private JagStream metaChannel;
        private JagStream[] indexChannels;

        /// <summary>
        /// Loads the main data, metadata, and indice files into a corresponding <c>JagStream</c>
        /// </summary>
        /// <param name="cacheDir">the base directory for the cache files</param>
        public RSFileStore(string cacheDir) {
            //Append the cache file name prefix
            cacheDir += "/main_file_cache.";

            //Load the cache into memory
            LoadFile(ref dataChannel, cacheDir + "dat2"); //Load the main data file
            LoadFile(ref metaChannel, cacheDir + "idx255"); //Load the metadata file

            int count = 0;

            //Count how many idx files exist
            for(int k = 0; k < 254; k++) {
                if(!File.Exists(cacheDir + "idx" + k)) {
                    //If we didn't read any, check the directory is set correctly
                    if(count == 0)
                        throw new FileNotFoundException("No index files could be found");
                    break;
                }
                count++;
            }

            //Initialise the index channels
            indexChannels = new JagStream[count];

            //And load in the data
            for(int k = 0; k < count; k++)
                LoadFile(ref indexChannels[k], cacheDir + "idx" + k);
        }

        /// <summary>
        /// Read the index data
        /// </summary>
        /// <param name="type">The index type</param>
        /// <param name="id">The container index</param>
        /// <returns>A <c>JagStream</c> containing the container data</returns>
        internal JagStream Read(int type, int id) {
            //Check if index is out of bounds
            if((type < 0 || type >= indexChannels.Length) && type != 255)
                throw new FileNotFoundException("Index " + type + " could not be found.");

            //Retrieve the index channel we are looking for
            JagStream indexChannel = type == 255 ? metaChannel : indexChannels[type];

            //Find the beginning of the index
            long pos = id * RSIndex.SIZE;

            if(pos < 0 || pos >= indexChannel.Length)
                throw new FileNotFoundException("Position is out of bounds for type " + type + ", id " + id);

            /*
             * Read the 6 byte Index header from the stream
             *      3 for the file size
             *      3 for the sector ID
             */

            indexChannel.Seek(pos);
            RSIndex index = new RSIndex(indexChannel.ReadMedium(), indexChannel.ReadMedium());
            indexChannel.Seek0();

            if(index.GetSize() < 0)
                return null;
            if(index.GetSector() <= 0 || index.GetSector() > dataChannel.Length / RSSector.SIZE)
                return null;

            //Allocate buffers for the data and sector
            JagStream data = new JagStream(index.GetSize());
            JagStream buf = new JagStream(RSSector.SIZE);

            int chunk = 0, remaining = index.GetSize();

            //Point to the start of the sector
            pos = index.GetSector() * RSSector.SIZE;

            do {
                buf.Clear();

                //Read from the data index into the sector buffer
                dataChannel.Seek(pos);

                //Read in the sector from the data channel
                RSSector sector = RSSector.Decode(dataChannel);

                if(remaining > RSSector.DATA_LEN) {
                    //Cache this sector so far
                    data.Write(sector.GetData(), 0, RSSector.DATA_LEN);

                    //And subtract the sector we read from data remaining
                    remaining -= RSSector.DATA_LEN;

                    if(sector.GetType() != type)
                        throw new IOException("File type mismatch.");

                    if(sector.GetId() != id)
                        throw new IOException("File id mismatch.");

                    if(sector.GetChunk() != chunk++)
                        throw new IOException("Chunk mismatch.");

                    //Then move the pointer to the next sector
                    pos = sector.GetNextSector() * RSSector.SIZE;
                } else {
                    //Otherwise if the amount remaining is less than the sector size, put it down
                    data.Write(sector.GetData(), 0, remaining);

                    //We've read the last sector in this index!
                    remaining = 0;
                }
            }
            while(remaining > 0);

            //Return the data stream back to it's original position
            dataChannel.Seek(0);

            return data.Flip();
        }

        /// <summary>
        /// Gets the number of files of the specified type.
        /// </summary>
        /// <param name="type">The index type</param>
        /// <returns>The number of files</returns>
        public int GetFileCount(int type) {
            if((type < 0 || type >= indexChannels.Length) && type != 255)
                throw new FileNotFoundException("Unable to get file count for type " + type);

            return (int) ((type == 255 ? metaChannel : indexChannels[type]).Length / RSIndex.SIZE);
        }

        /// <summary>
        /// Reads binary data from a file into the specified stream
        /// </summary>
        /// <param name="stream">The stream (reference) to read the data into</param>
        /// <param name="directory">The directory of the binary file</param>
        private void LoadFile(ref JagStream stream, string directory) {
            if(!File.Exists(directory)) {
                string errorMsg = "'" + directory + "' could not be found";
                DebugUtil.Debug(errorMsg);
                throw new FileNotFoundException(errorMsg);
            }

            byte[] data = File.ReadAllBytes(directory);
            if(data.Length == 0)
                DebugUtil.Debug("No data read for dir: " + directory);

            stream = new JagStream(data);
        }

        ///<summary>
        ///Writes binary data from a JagStream to a file
        /// </summary>
        /// <param name="stream">The stream to write to file</param>
        /// <param name="directory">The directory to write the file to</param>
        private void WriteFile(ref JagStream stream, string directory) {
            if(!File.Exists(directory))
                throw new FileNotFoundException("'" + directory + "' could not be found");

            using(FileStream file = new FileStream(directory, FileMode.Create, FileAccess.Write)) {
                byte[] bytes = new byte[stream.Length];
                stream.Read(bytes, 0, (int) stream.Length);
                file.Write(bytes, 0, bytes.Length);
                stream.Close();
            }
        }

        /// <summary>
        /// Returns the total number of non-meta indices
        /// </summary>
        /// <returns>The length of the <param name="indexChannels"> array</returns>
        internal int GetTypeCount() {
            return indexChannels.Length;
        }

        /// <summary>
        /// Disposes all of the memorystreams
        /// </summary>
        public void DisposeAll() {
            if(dataChannel != null)
                dataChannel.Dispose();

            if(metaChannel != null)
                metaChannel.Dispose();

            foreach(JagStream stream in indexChannels)
                if(stream != null)
                    stream.Dispose();
        }
    }
}
