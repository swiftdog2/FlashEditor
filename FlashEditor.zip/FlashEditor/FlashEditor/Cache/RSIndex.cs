﻿namespace FlashEditor.cache {
    class RSIndex {
        public const int SIZE = 6;
        private int sector;
        private int size;

        public RSIndex(int size, int sector) {
            this.size = size;
            this.sector = sector;
        }

        public int GetSize() {
            return size;
        }

        public int GetSector() {
            return sector;
        }
    }
}
