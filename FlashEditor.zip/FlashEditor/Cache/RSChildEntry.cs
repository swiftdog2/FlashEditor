﻿using System;

namespace FlashEditor.cache {
    public class RSChildEntry : RSEntry {
        public RSChildEntry() : base() {
        }

        public RSChildEntry(int index) : base(index) {

        }
    }
}
